# Informations

Ce projet CPOA a été conçu dans le cadre d'un projet de reprise des cours en IUT Informatique de deuxième année.

# Niveaux atteints

## Niveau 1
Complete on 06/09/2021 - 09h02

## Niveau 2
Complete on 06/09/2021 - 15h25

## Niveau 3
Complete on 06/09/2021 - 15h31

## Niveau 4
Complete on 06/09/2021 - 19h05

## Niveau 5
Complete on 06/09/2021 - 21h29

## Niveau 6
Complete on 07/09/2021 - 11h05

## Niveau 7
Complete on 07/09/2021 - 11h25

## Niveau 8
Complete on 07/09/2021 - 18h59

## Niveau 9
Complete on 07/09/2021 - 19h48

## Niveau 10
Complete on 07/09/2021 - 20h26

## Niveau 11
Complete on 07/09/2021 - 20h34

## Niveau 12
Complete on 07/09/2021 - 20h50

## Niveau 13
Complete on 07/09/2021 - 21h14

## Niveau 14
Complete on 08/09/2021 - 21h02

## Niveau 15
Complete on 08/09/2021 - 21h02

## Niveau 16
Complete on 13/09/2021 - 14h03

## Niveau 17
Complete on 13/09/2021 - 14h13

## Niveau 18
Complete on 13/09/2021 - 14h13

## Niveau 19
Complete on 15/09/2021 - 14h49

## Niveau 20
Complete on 15/09/2021 - 15h19

## Niveau 21
Complete on 15/09/2021 - 15h30

## Niveau 22
Complete on 15/09/2021 - 15h32

## Niveau 23
Complete on 15/09/2021 - 18h16

## Niveau 24
Complete on 15/09/2021 - 18h50

## Niveau 25
Complete on 15/09/2021 - 19h40

## Niveau 26
Complete on 15/09/2021 - 10h04

## Niveau 27
Complete on 16/09/2021 - 19h47

## Niveau 28
Complete on 16/09/2021 - 20h00